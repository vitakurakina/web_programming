<?php
declare(strict_types=1);

namespace lab1\Classes;

interface SuperUserInterface {
    public function getInfo(): array;
}

?>