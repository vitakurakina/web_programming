<?php
	define('DB_HOST', 'localhost');
	define('DB_USER', 'n93077gb_mvc');
	define('DB_PASS', 'Qwerty123_');
	define('DB_NAME', 'n93077gb_mvc');
