<h1>Информация о пользователе</h1>
<p><strong>ID:</strong> <?= $id ?></p>
<p><strong>Имя:</strong> <?= $user['name'] ?></p>
<p><strong>Возраст:</strong> <?= $user['age'] ?></p>
<p><strong>Зарплата:</strong> <?= $user['salary'] ?></p>

