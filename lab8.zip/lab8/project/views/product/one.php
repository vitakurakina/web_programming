<h1><?= $h1; ?></h1>
<div id="content">
	<p><strong>Название:</strong> <?= $name; ?></p>
	<p><strong>Цена:</strong> <?= $price; ?> руб.</p>
	<p><strong>Количество:</strong> <?= $quantity; ?> шт.</p>
	<p><strong>Описание:</strong></p>
	<p><?= $description; ?></p>
</div>

