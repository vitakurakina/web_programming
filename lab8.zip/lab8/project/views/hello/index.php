<h1>Все работает!</h1>
<p>Проверка отображения картинки:</p>
<img src="<?= BASE_PATH ?>/project/webroot/logo.jpg" alt="Логотип MVC Framework">
