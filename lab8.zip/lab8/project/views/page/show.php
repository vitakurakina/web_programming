<h1><?= $page['title'] ?></h1>
<p><?= $page['text'] ?></p>

